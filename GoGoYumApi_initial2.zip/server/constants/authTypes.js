const authTypes = {
    SERVER_TOKEN: 'server_bearer_token',
    CLIENT_TOKEN: 'client_bearer_token',
    ANONYMOUS: 'anonymous'
}

export default authTypes;